// AdminSettings.js
import React from "react";
import PageTemplate from "./PageTemplate";
const AdminSettings = () => <PageTemplate fileKey="admin_settings" title="Admin Settings" />;
export default AdminSettings;
