import React from 'react';
import { Link } from 'react-router-dom';

const AllPagesPreview = () => {
  const pages = [
    "dashboard",
    "productInfo",
    "orderInfo",
    "userProfiles",
    "inventoryData",
    "paymentInfo",
    "shippingData",
    "reviews",
    "analytics",
    "promotions",
    "adminSettings",
    "legalData"
  ];

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">🔍 Preview All Pages</h1>
      <ul className="list-disc list-inside space-y-2">
        {pages.map((page) => (
          <li key={page}>
            <Link to={`/${page}`} className="text-blue-600 hover:underline">
              /{page}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AllPagesPreview;
