// Analytics.js
import React from "react";
import PageTemplate from "./PageTemplate";
const Analytics = () => <PageTemplate fileKey="analytics" title="Analytics" />;
export default Analytics;
