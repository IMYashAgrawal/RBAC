import React from "react";
import { Link, Navigate } from "react-router-dom";
import { useAuth } from "../auth";
import permissions from "../roles/permissions";

const sampleProducts = [
  { name: "iPhone 15", image: "https://via.placeholder.com/150?text=iPhone+15" },
  /* … */
];

const Dashboard = () => {
  const { user, loading } = useAuth();

  if (loading) return <div className="p-4">Loading...</div>;
  if (!user)    return <Navigate to="/" />;

  const hasProductAccess = permissions[user.role]["Product Info"] !== "NA";
  const pages = Object.entries(permissions[user.role])
    .filter(([, perm]) => perm !== "NA")
    .map(([name]) => ({
      name,
      path: `/${name.toLowerCase().replace(/ /g, "-")}`
    }));

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Welcome, {user.username}</h2>

      {hasProductAccess && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Available Products</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {sampleProducts.map((p,i) => (
              <div key={i} className="bg-white rounded shadow p-2 text-center">
                <img src={p.image} alt={p.name} className="mx-auto mb-2" />
                <p className="font-medium">{p.name}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        {pages.map((p,i) => (
          <Link key={i} to={p.path} className="p-4 bg-gray-100 rounded shadow text-center">
            {p.name}
          </Link>
        ))}
      </div>

      <div className="mt-6 text-center">
        <Link to="/edit-profile" className="text-blue-600 underline">Edit Profile</Link>
      </div>
    </div>
  );
};

export default Dashboard;
