
import React, { useState } from "react";
import axios from "axios";
import { useAuth } from "../auth";

const EditProfile = () => {
  const { user } = useAuth();
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setNewPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("/api/update-password", {
        username: user.username,
        newPassword,
      });
      setMessage(res.data.message);
    } catch {
      setMessage("Failed to update password.");
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Edit Profile</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="password"
          value={newPassword}
          onChange={handleChange}
          placeholder="New Password"
          className="w-full p-2 border mb-4"
        />
        <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded">
          Update Password
        </button>
      </form>
      {message && <p className="mt-4 text-green-600">{message}</p>}
    </div>
  );
};

export default EditProfile;
