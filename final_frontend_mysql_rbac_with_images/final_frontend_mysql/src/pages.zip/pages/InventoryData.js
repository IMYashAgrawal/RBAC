// InventoryData.js
import React from "react";
import PageTemplate from "./PageTemplate";
const InventoryData = () => <PageTemplate fileKey="inventory_data" title="Inventory Data" />;
export default InventoryData;
