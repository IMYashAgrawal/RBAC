// LegalData.js
import React from "react";
import PageTemplate from "./PageTemplate";
const LegalData = () => <PageTemplate fileKey="legal_data" title="Legal Data" />;
export default LegalData;
