// OrderInfo.js
import React from "react";
import PageTemplate from "./PageTemplate";
const OrderInfo = () => <PageTemplate fileKey="order_info" title="Order Info" />;
export default OrderInfo;
