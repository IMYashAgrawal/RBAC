import { useEffect, useState } from "react";
import { useAuth } from "../auth";
import permissions from "../roles/permissions";
import api from "../services/api"; // Use your configured axios instance!
import { Navigate } from "react-router-dom";

const PageTemplate = ({ fileKey, title }) => {
  const { user, loading } = useAuth();
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!loading && user) {
      api
        .get(`/api/text-file?name=${fileKey}`)
        .then((res) => setContent(res.data.content))
        .catch((err) => {
          setContent("");
          setMsg(err.response?.data?.error || "Failed to load content.");
        });
    }
  }, [loading, user, fileKey]);

  if (loading) return <div className="p-4">Loading...</div>;
  if (!user) return <Navigate to="/" />;

  const perm = permissions[user.role]?.[title] || "NA";
  if (perm === "NA") return <Navigate to="/unauthorized" />;
  const readOnly = perm === "R";

  const handleSave = () => {
    setSaving(true);
    api
      .post("/api/text-file", { name: fileKey, content })
      .then((res) => setMsg(res.data.message || "Saved."))
      .catch((err) => setMsg(err.response?.data?.error || "Save failed."))
      .finally(() => setSaving(false));
  };

  // Optional: auto-clear messages after a few seconds
  useEffect(() => {
    if (msg) {
      const timer = setTimeout(() => setMsg(""), 3000);
      return () => clearTimeout(timer);
    }
  }, [msg]);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <textarea
        className="w-full h-64 border p-2"
        value={content}
        readOnly={readOnly}
        onChange={(e) => setContent(e.target.value)}
      />
      {perm === "R/W" && (
        <button
          onClick={handleSave}
          disabled={saving}
          className="mt-4 bg-blue-500 text-white px-4 py-2 rounded"
        >
          {saving ? "Saving…" : "Save"}
        </button>
      )}
      {msg && <p className="mt-2 text-sm text-green-600">{msg}</p>}
    </div>
  );
};

export default PageTemplate;
