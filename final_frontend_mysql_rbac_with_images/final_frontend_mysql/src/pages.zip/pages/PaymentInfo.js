// PaymentInfo.js
import React from "react";
import PageTemplate from "./PageTemplate";
const PaymentInfo = () => <PageTemplate fileKey="payment_info" title="Payment Info" />;
export default PaymentInfo;
