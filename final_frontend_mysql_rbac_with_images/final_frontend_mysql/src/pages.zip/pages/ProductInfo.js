// ProductInfo.js
import React from "react";
import PageTemplate from "./PageTemplate";
const ProductInfo = () => <PageTemplate fileKey="product_info" title="Product Info" />;
export default ProductInfo;
