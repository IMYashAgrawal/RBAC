// Promotions.js
import React from "react";
import PageTemplate from "./PageTemplate";
const Promotions = () => <PageTemplate fileKey="promotions" title="Promotions" />;
export default Promotions;
