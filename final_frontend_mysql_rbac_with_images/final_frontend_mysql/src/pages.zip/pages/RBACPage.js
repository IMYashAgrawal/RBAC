import React from "react";
import { useParams, Navigate } from "react-router-dom";
import { useAuth } from "../auth";
import permissions from "../roles/permissions";

const RBACPage = () => {
  const { page } = useParams();        // e.g. "product-info"
  const { user, loading } = useAuth();

  if (loading) return <div className="p-4">Loading...</div>;
  if (!user)    return <Navigate to="/" />;

  // turn "product-info" → "Product Info"
  const displayName = page
    .split("-")
    .map(w => w[0].toUpperCase() + w.slice(1))
    .join(" ");

  const perm = permissions[user.role]?.[displayName];

  // if they have no access, send them to /unauthorized
  if (!perm || perm === "NA") return <Navigate to="/unauthorized" />;

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">{displayName}</h2>
      <p>You have <strong>{perm}</strong> access to this page.</p>
      {/* TODO: render the real content for {displayName} here */}
    </div>
  );
};

export default RBACPage;
