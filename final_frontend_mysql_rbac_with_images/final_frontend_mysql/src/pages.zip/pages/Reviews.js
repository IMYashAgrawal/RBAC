// Reviews.js
import React from "react";
import PageTemplate from "./PageTemplate";
const Reviews = () => <PageTemplate fileKey="reviews" title="Reviews" />;
export default Reviews;
