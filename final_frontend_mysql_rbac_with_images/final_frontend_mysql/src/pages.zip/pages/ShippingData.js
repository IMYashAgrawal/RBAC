// ShippingData.js
import React from "react";
import PageTemplate from "./PageTemplate";
const ShippingData = () => <PageTemplate fileKey="shipping_data" title="Shipping Data" />;
export default ShippingData;
