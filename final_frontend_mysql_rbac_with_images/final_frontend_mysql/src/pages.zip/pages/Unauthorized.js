
import React from "react";

const Unauthorized = () => (
  <div className="text-center p-6 text-red-500">
    <h1 className="text-2xl font-bold">403 - Unauthorized</h1>
    <p>You do not have permission to access this page.</p>
  </div>
);

export default Unauthorized;
