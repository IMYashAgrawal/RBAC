// UserProfiles.js
import React from "react";
import PageTemplate from "./PageTemplate";
const UserProfiles = () => <PageTemplate fileKey="user_profiles" title="User Profiles" />;
export default UserProfiles;
